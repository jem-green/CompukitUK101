;MONUK01 for 48x16
*=$F800
;Disk controller init & load track 0 for C4PMF?
Sff90 = $FF90
Lf800               LDY #$00
                    STY $c001
                    STY $c000
                    LDX #$04
                    STX $c001
                    STY $c003
                    DEY
                    STY $c002
                    STX $c003
                    STY $c002
                    LDA #$fb
                    BNE Lf827
Lf81e               LDA #$02
                    BIT $c000
                    BEQ Lf841
                    LDA #$ff
Lf827               STA $c002
                    JSR Sff99
                    AND #$f7
                    STA $c002
                    JSR Sff99
                    ORA #$08
                    STA $c002
                    LDX #$18
                    JSR Sff85
                    BEQ Lf81e
Lf841               LDX #$7f
                    STX $c002
                    JSR Sff85
Lf849               LDA $c000
                    BMI Lf849
Lf84e               LDA $c000
                    BPL Lf84e
                    LDA #$03
                    STA $c010
                    LDA #$58
                    STA $c010
                    JSR Sff90
                    STA $fe
                    TAX
                    JSR Sff90
                    STA $fd
                    JSR Sff90
                    STA $ff
                    LDY #$00
Lf86f               JSR Sff90
                    STA ($fd),y
                    INY
                    BNE Lf86f
                    INC $fe
                    DEC $ff
                    BNE Lf86f
                    STX $fe
                    LDA #$ff
                    STA $c002
                    RTS
                    
Lf885               LDY #$f8
Lf887               DEY
                    BNE Lf887
                    EOR $ff,x
                    DEX
                    BNE Lf885
                    RTS
                    
Lf890               LDA $c010
                    LSR a
                    BCC Lf890
                    LDA $c011
                    RTS
                    
Lf89a               .BYTE 'H/D/M?'
LF8A0 
                    CLD 
Lf8a1               LDX #$d8
                    LDA #$d0
                    STA $fe
                    LDY #$00
                    STY $fd
                    LDA #$20
Lf8ad               STA ($fd),y
                    INY
                    BNE Lf8ad
                    INC $fe
                    CPX $fe
                    BNE Lf8ad
                    LDA #$03
                    STA Lfc00
                    LDA #$b1
                    STA Lfc00
Lf8c2               LDA Sff99+1,y
                    BMI Lf8d5
                    STA $d0c6,y
                    LDX Lfe00+1
                    BNE Lf8d2
                    JSR Sfe0b
Lf8d2               INY
                    BNE Lf8c2
Lf8d5               LDA Lfe00+1
                    BNE Lf8df
                    JSR Lfe00
                    BCS Lf8e2
Lf8df               JSR Sfeed
Lf8e2               CMP #$48
                    BEQ Lf8f0
                    CMP #$44
                    BNE Lf8f6
                    JSR LFF00
                    JMP $2200	;default disk load address
                    
Lf8f0               JMP Lfd00
                    
					JSR LFF00
Lf8f6               JMP ($fefc)
                    
                    
					.BYTE $ea,$30,$01,$a0,$ff,$c0,$01
					
;key poller for C2/C4
Lf900               TXA
                    PHA
                    TYA
                    PHA
Lf904               LDA #$01
Lf906               STA $df00
                    LDX $df00
                    BNE Lf913
Lf90e               ASL A
                    BNE Lf906
                    BEQ Lf966
Lf913               LSR A
                    BCC Lf91f
                    ROL A
                    CPX #$21
                    BNE Lf90e
                    LDA #$1b
                    BNE Lf940
Lf91f               JSR Sfdc8
                    TYA
                    STA $0213
                    ASL A
                    ASL A
                    ASL A
                    SEC
                    SBC $0213
                    STA $0213
                    TXA
                    LSR A
                    JSR Sfdc8
                    BNE Lf966
                    CLC
                    TYA
                    ADC $0213
                    TAY
                    LDA $fdcf,y
Lf940               CMP $0215
                    BNE Lf96b
                    DEC $0214
                    BEQ Lf975
                    LDY #$05
Lf94c               LDX #$c8
Lf94e               DEX
                    BNE Lf94e
                    DEY
                    BNE Lf94c
                    BEQ Lf904
Lf956               CMP #$01
                    BEQ Lf98f
                    LDY #$00
                    CMP #$02
                    BEQ Lf9a7
                    LDY #$c0
                    CMP #$20
                    BEQ Lf9a7
Lf966               LDA #$00
                    STA $0216
Lf96b               STA $0215
                    LDA #$02
                    STA $0214
                    BNE Lf904
Lf975               LDX #$96
                    CMP $0216
                    BNE Lf97e
                    LDX #$14
Lf97e               STX $0214
                    STA $0216
                    LDA #$01
                    STA $df00
                    LDA $df00
                    LSR a
                    BCC Lf9c2
Lf98f               TAX
                    AND #$03
                    BEQ Lf99f
                    LDY #$10
                    LDA $0215
                    BPL Lf9a7
                    LDY #$f0
                    BNE Lf9a7
Lf99f               LDY #$00
                    CPX #$20
                    BNE Lf9a7
                    LDY #$c0
Lf9a7               LDA $0215
                    AND #$7f
                    CMP #$20
                    BEQ Lf9b7
                    STY $0213
                    CLC
                    ADC $0213
Lf9b7               STA $0213
                    PLA
                    TAY
                    PLA
                    TAX
                    LDA $0213
                    RTS
                    
Lf9c2               BNE Lf956
                    LDY #$20
                    BNE Lf9a7
                    LDY #$08
Lf9ca               DEY
                    ASL a
                    BCC Lf9ca
                    RTS
					.BYTE $D0,$BB,$2F,$20,$5A,$41,$51 ;/ ZAQ,MNBVCXKJHGFDSIUYTREW
                    .BYTE $2C,$4D,$4E,$42,$56,$43,$58
                    .BYTE $4B,$4A,$48,$47,$46,$44,$53
                    .BYTE $49,$55,$59,$54,$52,$45,$57
                    .BYTE $00,$00,$0D,$0A,$4F,$4C,$2E
                    .BYTE $00,$FF,$2D,$BA,$30,$B9,$B8
                    .BYTE $B7,$B6,$B5,$B4,$B3,$B2,$B1                    

;init for C2/C4
Lfa00               LDX #$28
                    TXS
                    CLD
                    LDA $fb06
                    LDA #$ff
                    STA $fb05
                    LDX #$d8
                    LDA #$d0
                    STA $ff
                    LDA #$00
                    STA $fe
                    STA $fb
                    TAY
                    LDA #$20
Lfa1b               STA ($fe),y
                    INY
                    BNE Lfa1b
                    INC $ff
                    CPX $ff
                    BNE Lfa1b
                    STY $ff
                    BEQ Lfa43
Lfa2a               JSR Sfee9
                    CMP #$2f
                    BEQ Lfa4f
                    CMP #$47
                    BEQ Lfa4c
                    CMP #$4c
                    BEQ Lfa7c
                    JSR Sfe93
                    BMI Lfa2a
                    LDX #$02
                    JSR Sfeda
Lfa43               LDA ($fe),y
                    STA $fc
                    JSR Sfeac
                    BNE Lfa2a
Lfa4c               JMP ($00fe)
                    
Lfa4f               JSR Sfee9
                    CMP #$2e
                    BEQ Lfa2a
                    CMP #$0d
                    BNE Lfa69
                    INC $fe
                    BNE Lfa60
                    INC $ff
Lfa60               LDY #$00
                    LDA ($fe),y
                    STA $fc
                    JMP Lfe77
                    
Lfa69               JSR Sfe93
                    BMI Lfa4f
                    LDX #$00
                    JSR Sfeda
                    LDA $fc
                    STA ($fe),y
                    JSR Sfeac
                    BNE Lfa4f
Lfa7c               STA $fb
Lfa7e               BEQ Lfa4f
Lfa80               LDA $FC00
                    LSR A
                    BCC Lfa80
                    LDA $FC01
                    NOP
                    NOP
                    NOP
                    AND #$7f
                    RTS
                    
                    .BYTE $0,$0,$0,$0
                     
Lfa93               CMP #$30
                    BMI Lfaa9
                    CMP #$3a
                    BMI Lfaa6
                    CMP #$41
                    BMI Lfaa9
                    CMP #$47
                    BPL Lfaa9
                    SEC
                    SBC #$07
Lfaa6               AND #$0f
                    RTS
                    
Lfaa9               LDA #$80
                    RTS
                    
Lfaac               LDX #$03
                    LDY #$00
Lfab0               LDA $fc,x
                    LSR a
                    LSR a
                    LSR a
                    LSR a
                    JSR Sfeca
                    LDA $fc,x
                    JSR Sfeca
                    DEX
                    BPL Lfab0
                    LDA #$20
                    STA $d0ca
                    STA $d0cb
                    RTS
                    
Lfaca               AND #$0f
                    ORA #$30
                    CMP #$3a
                    BMI Lfad5
                    CLC
                    ADC #$07
Lfad5               STA $d0c6,y
                    INY
                    RTS
                    
Lfada               LDY #$04
                    ASL a
                    ASL a
                    ASL a
                    ASL a
Lfae0               ROL a
                    ROL $fc,x
                    ROL $fd,x
                    DEY
                    BNE Lfae0
                    RTS
                    
Lfae9               LDA $fb
                    BNE Lfa7e
                    JMP Lfd00
                    
Lfaf0               LDA #$ff
                    STA $df00
                    LDA $df00
                    RTS
                    NOP
					.BYTE $30,$01
					.BYTE $00,$fe
					.BYTE $c0,$01
;Init for C4P?
Lfb00               CLD
                    LDX #$28
                    TXS
                    JSR $bf22
                    LDY #$00
                    STY $0212
                    STY $0203
                    STY $0205
                    STY $0206
                    LDA LFFE0
                    STA $0200
                    LDA #$20
Lfb1d               STA $d700,y
                    STA $d600,y
                    STA $d500,y
                    STA $d400,y
                    STA $d300,y
                    STA $d200,y
                    STA $d100,y
                    STA $d000,y
                    INY
                    BNE Lfb1d
Lfb38               ;LDA $ff5f,y
                    RTS
					NOP
					NOP
                    BEQ Lfb43
                    JSR $bf2d
                    INY
                    BNE Lfb38
Lfb43               JSR $ffb8
                    CMP #'M
                    BNE Lfb4d
                    JMP Lfe00
                    
Lfb4d               CMP #'W
                    BNE Lfb54
                    JMP $0000
                    
Lfb54               CMP #'C
                    BNE Lfb00
                    LDA #$00
                    TAX
                    TAY
                    JMP $bd11
                    
                    .BYTE 'C/W/M ?',0
Lfb67               JSR $bf2d
                    PHA
                    LDA $0205
                    BEQ Lfb92
                    PLA
                    JSR $bf15
                    CMP #$0d
                    BNE Lfb93
                    PHA
                    TXA
                    PHA
                    LDX #$0a
                    LDA #$00
Lfb7f               JSR $bf15
                    DEX
                    BNE Lfb7f
                    PLA
                    TAX
                    PLA
                    RTS
                    
Lfb89               PHA
                    DEC $0203
                    LDA #$00
Lfb8f               STA $0205
Lfb92               PLA
Lfb93               RTS
                    
Lfb94               PHA
                    LDA #$01
                    BNE Lfb8f
                    LDA $0212
                    BNE Lfbb7
                    LDA #$01
                    STA $df00
                    BIT $df00
                    BVC Lfbb7
                    LDA #$04
                    STA $df00
                    BIT $df00
                    BVC Lfbb7
                    LDA #$03
                    JMP $a636
                    
Lfbb7               RTS
                    
Lfbb8               BIT $0203
                    BPL Lfbd6
Lfbbd               LDA #$02
                    STA $df00
                    LDA #$10
                    BIT $df00
                    BNE Lfbd3
                    LDA $FC00
                    LSR a
                    BCC Lfbbd
                    LDA $FC01
                    RTS
                    
Lfbd3               INC $0203
Lfbd6               JMP Sfeed
                    .BYTE $00,$00,$00,$00,$00,$00,$00 
					.BYTE $40,$3f,$01,$00,$03,$ff,$3f 
					.BYTE $00,$03,$ff,$3f 
Lfbeb               JMP $FFB8
                    
Lfbee               JMP $ff67
                    
Lfbf1               JMP Sff99
                    
Lfbf4               JMP Lff89
                    
Lfbf7               JMP Lff94
                    
					.BYTE $30,$01
					.BYTE $00,$FF
					.BYTE $C0,$01
					
;initialize disk controller & load track 0
Lfc00               JSR Sfc0c
                    JMP ($00fd)   ;jump to address loaded from disk (usually $2200)
Lfc06               JSR Sfc0c     
                    JMP Lfe00     
Sfc0c               LDY #$00      ;init disk controller
                    STY $c001     ;select DDRA.
                    STY $c000     ;0's in DDRA indicate input.
                    LDX #$04      
                    STX $c001     ;select PORTA
                    STY $c003     ;select DDRB
                    DEY           
                    STY $c002     ;1's in DDRB indicate output.
                    STX $c003     ;select PORT B
                    STY $c002     ;make all outputs high
                    LDA #$fb      ;set step towards 0
                    BNE Lfc33     
Lfc2a               LDA #$02      
                    BIT $c000     
                    BEQ Lfc4d     ;track 0 enabled?
                    LDA #$ff      
Lfc33               STA $c002     ;step off
                    JSR Sfca5     ; short delay
                    AND #$f7      
                    STA $c002     ;step on
                    JSR Sfca5     ; short delay
                    ORA #$08      
                    STA $c002     ;step off
                    LDX #$18      ;3ms delay @ 1MHz
                    JSR Sfc91     
                    BEQ Lfc2a     
Lfc4d               LDX #$7f      ;load head
                    STX $c002     
                    JSR Sfc91     ;delay 158 ms @ 1MHz
Lfc55               LDA $c000     
                    BMI Lfc55     ;wait for index start
Lfc5a               LDA $c000     
                    BPL Lfc5a     ;wait for index end
                    LDA #$03      
                    STA $c010     ;reset ACIA
                    LDA #$58      
                    STA $c010     ;/1 RTS hi, no irq
                    JSR Sfc9c     
                    STA $fe       ;read start addr hi
                    TAX           
                    JSR Sfc9c     
                    STA $fd       ;read start addr lo
                    JSR Sfc9c     
                    STA $ff       ;read num pages value
                    LDY #$00      
Lfc7b               JSR Sfc9c     ;read the specified num pages
                    STA ($fd),y   ;to specified address
                    INY           
                    BNE Lfc7b     
                    INC $fe       
                    DEC $ff       
                    BNE Lfc7b     
                    STX $fe       ;restore start addr hi
                    LDA #$ff      ;disable drive
                    STA $c002     
                    RTS           
Sfc91               LDY #$f8      ;delay for 1250 clock cycles * X
Lfc93               DEY           
                    BNE Lfc93     
                    EOR $ff,x     ;( extra instruction for time delay)
                    DEX           
                    BNE Sfc91     
                    RTS           
Sfc9c               LDA $c010     ;wait for disk ACIA char
                    LSR a         
                    BCC Sfc9c     
                    LDA $c011     
Sfca5               RTS           
Sfca6               LDA #$03      ;RESET serial ACIA @ $F000
                    STA $f000     
                    LDA #$11      ; set 8N2 /16 RTS NOIRQ
                    STA $f000     
                    RTS           
Sfcb1               PHA           
Lfcb2               LDA $f000     ;write to ACIA when possible
                    LSR a         
                    LSR a         
                    BCC Lfcb2     
                    PLA           
                    STA $f001     
                    RTS           
Sfcbe               EOR #$ff       ;Set inverted KB ROW (C1 patch for $FD00 keypoller)
                    STA $df00     
                    EOR #$ff      
                    RTS           
Sfcc6               PHA            ;load KB inverted COL to X
                    JSR Sfccf     
                    TAX           
                    PLA           
                    DEX           
                    INX           
                    RTS           
Sfccf               LDA $df00      ;load KB COL (C1 patch for $FD00 keypoller)
                    EOR #$ff
                    RTS
Lfcd5               CMP #$1c
                    BEQ Lfcdc
                    JMP $a374
Lfcdc               DEX
                    BPL Lfce3
                    INX
                    JMP $a359
Lfce3               TXA
                    PHA
                    LDX $0200
                    LDA #$20
                    STA $d300,x
                    DEC $0200
                    DEX
                    LDA #$9a
                    STA $d300,x
                    PLA
                    TAX
                    JMP $a359
                    
                    .BYTE $ff,$ff,$ff,$ff,$ff

;key poller for C1P/UK101

;$0213 = temp storage for KB calculations
;$0214 = debounce counter
;$0215 = current key pressed
;$0216 = last key pressed
					
Lfd00               TXA            ;entry point for get keypress
                    PHA            
                    TYA            
                    PHA            
Lfd04               LDA #$01       ;start with row 0
Lfd06               JSR Sfcbe      ;select row in A
                    JSR Sfcc6      ;read selected row's columns to X
                    BNE Lfd13      ;branch if any column set
Lfd0e               ASL a          
                    BNE Lfd06      
                    BEQ Lfd66      
Lfd13               LSR a          ;test if row 0 selected
                    BCC Lfd1f      ;branch if not
                    ROL a          ;restore A
                    CPX #$21       ; is ESC + CAPLOCK set?
                    BNE Lfd0e      
                    LDA #$1b       ;load ESC value
                    BNE Lfd40      ;branch always
Lfd1f               JSR Sfdc8      ;return Y=leftmost bit set of A (0-7)
                    TYA            
                    STA $0213      ;multiply A (ROW) by 7
                    ASL a          
                    ASL a          
                    ASL a          ;A*8
                    SEC            
                    SBC $0213      ;-A
                    STA $0213      ;store row*7
                    TXA            ;X=current col
                    LSR a          ; /2
                    JSR Sfdc8      ;Y = 0-7 current row
                    BNE Lfd66      ; (multiple keys pressed? branch as if no keys press
                    CLC            
                    TYA            ; calculate row*7+col
                    ADC $0213      
                    TAY            
                    LDA Lfdcf,y     ;lookup key in table
Lfd40               CMP $0215       ;same as last key pressed?
                    BNE Lfd6b      
                    DEC $0214       ;dec debounce counter
                    BEQ Lfd75       ;branch when debounce done
                    LDY #$05        ;time delay 5ms @1MHz (5031 ticks)
Lfd4c               LDX #$c8       
Lfd4e               DEX            
                    BNE Lfd4e      
                    DEY            
                    BNE Lfd4c      
                    BEQ Lfd04      ;loop back to keyscan top
Lfd56               CMP #$01       ;(r-shift?)
                    BEQ Lfd8f      ;(incorrect R-Shift + key code returned $10 too high
                    LDY #$00       
                    CMP #$02       ;(l-shift?)
                    BEQ Lfda7      
                    LDY #$c0       
                    CMP #$20       ;(ctrl?)
                    BEQ Lfda7      
Lfd66               LDA #$00       ;(enter here when no keys pressed)
                    STA $0216      
Lfd6b               STA $0215      ;save current key pressed
                    LDA #$02       
                    STA $0214      ;debounce value upon new key pressed
                    BNE Lfd04      ;(loop back to key scan top)
Lfd75               LDX #$96       ;auto-repeat loop delay value
                    CMP $0216      ;is this the same as last key?
                    BNE Lfd7e      
                    LDX #$14       
Lfd7e               STX $0214      ;(96=auto repeat delay, 14=new key delay)
                    STA $0216      ;store key as 'last' key value
                    LDA #$01       ;get KB row 0 columns
                    JSR Sfcbe      ;select KB row
                    JSR Sfccf      ;get KB column
                    LSR a          
                    BCC Lfdc2      ;shift-lock pressed? branch if not
Lfd8f               TAX            
                    AND #$03       ;left or right shift pressed?
                    BEQ Lfd9f      ;branch if not
                    LDY #$10       ;Y=amount to add to get shifted keycode
                    LDA $0215      ;is keycode high bit set? aka is it shiftable?
                    BPL Lfda7      ;branch if not
                    LDY #$f0       ;y=-$10 ('1'-$10 = '!')
                    BNE Lfda7      
Lfd9f               LDY #$00       ;y=amount to add for shifted value
                    CPX #$20       ;is CTRL pressed?
                    BNE Lfda7      
                    LDY #$c0       ;'A'+$C0 = CTRL+A value
Lfda7               LDA $0215      ;return key value in $0215
                    AND #$7f       ;mask high bit
                    CMP #$20       
                    BEQ Lfdb7      
                    STY $0213      ;Y=value to add to keycode
                    CLC            
                    ADC $0213      
Lfdb7               STA $0213      
                    PLA            
                    TAY            
                    PLA            
                    TAX            
                    LDA $0213      
                    RTS            
Lfdc2               BNE Lfd56      ;if any row 0 key pressed, branch
                    LDY #$20       ;amount to add to key to make it lower case
                    BNE Lfda7      
Sfdc8               LDY #$08       ;convert Y to rightmost column set
Lfdca               DEY            
                    ASL a          
                    BCC Lfdca      
                    RTS            ;return Z flag set when only 1 bit set in A
Lfdcf                ;keyboard key decode table
					.BYTE $D0,$BB,$2F,$20,$5A,$41,$51 ;/ ZAQ,MNBVCXKJHGFDSIUYTREW
                    .BYTE $2C,$4D,$4E,$42,$56,$43,$58
                    .BYTE $4B,$4A,$48,$47,$46,$44,$53
                    .BYTE $49,$55,$59,$54,$52,$45,$57
                    .BYTE $00,$00,$0D,$5E,$4F,$4C,$2E
                    .BYTE $00,$1C,$2D,$BA,$30,$B9,$B8
                    .BYTE $B7,$B6,$B5,$B4,$B3,$B2,$B1                     

;ROM monitor C1P/UK101
; 65V monitor for C1 FE00-FEFF
;$FC = current value
;$FD = not written but temporarily hex value copied to screen between addr & value
;$FE = current address low
;$FF = current address high
;
Lfe00               LDX #$28          ;set stack top & clear decimal mode
                    TXS               
                    CLD               
                    NOP               
                    NOP               
                    NOP               
                    NOP               
                    NOP               
                    NOP               
                    NOP               
Sfe0b               NOP               
                    LDX #$d4          ;(end page for screen clear  1K)
                    LDA #$d0          ;(start page for screen clear)
                    STA $ff           
                    LDA #$00          
                    STA $fe           
                    STA $fb           ;load flag for monitor
                    TAY               
                    LDA #$20          
Lfe1b               STA ($fe),y       ;erase screen
                    INY               
                    BNE Lfe1b         
                    INC $ff           
                    CPX $ff           
                    BNE Lfe1b         ;loop until end page reached
                    STY $ff           ;set initial address to 0000
                    BEQ Lfe43         
Lfe2a               JSR Sfee9         ;get key from input (KB or ACIA)
                    CMP #$2f          ;'/
                    BEQ Lfe4f         
                    CMP #$47          ; G
                    BEQ Lfe4c         
                    CMP #$4c          ; L
                    BEQ Lfe7c         ;set load flag
                    JSR Sfe93         
                    BMI Lfe2a         
                    LDX #$02          
                    JSR Sfeda         
Lfe43               LDA ($fe),y       
                    STA $fc           
                    JSR Sfeac         
                    BNE Lfe2a         
Lfe4c               JMP ($00fe)       ;monitor "GO" command
                                      
Lfe4f               JSR Sfee9         ;'.
                    CMP #$2e          
                    BEQ Lfe2a         ;<CR>
                    CMP #$0d          
                    BNE Lfe69         
                    INC $fe           
                    BNE Lfe60         
                    INC $ff           
Lfe60               LDY #$00          ;read value from memory
                    LDA ($fe),y       
                    STA $fc           
                    JMP Lfe77         
Lfe69               JSR Sfe93         
                    BMI Lfe4f         
                    LDX #$00          
                    JSR Sfeda         
                    LDA $fc           
                    STA ($fe),y       
Lfe77               JSR Sfeac         
                    BNE Lfe4f         ;(load flag for monitor)
Lfe7c               STA $fb           
                    BEQ Lfe4f         ; wait for character from ACIA
Lfe80               LDA $f000         
                    LSR a             
                    BCC Lfe80         ;return low 7 bits of value read
                    LDA $f001
                    NOP
                    NOP
                    NOP
                    AND #$7f
                    RTS
                    .BYTE $0,$0,$0,$0
Sfe93               CMP #$30         ;convert HEX to binary nibble lo or $80 on err
                    BMI Lfea9        
                    CMP #$3a         ;':
                    BMI Lfea6        
                    CMP #$41         ;'A
                    BMI Lfea9        
                    CMP #$47         ;'G
                    BPL Lfea9        
                    SEC              
                    SBC #$07         
Lfea6               AND #$0f         
                    RTS              
Lfea9               LDA #$80         
                    RTS              
Sfeac               LDX #$03         ;display hex address to screen
                    LDY #$00         ;y=starting position offset on screen
Lfeb0               LDA $fc,x        ;write hex byte to screen * 4 in reverse order
                    LSR a            
                    LSR a            
                    LSR a            
                    LSR a            
                    JSR Sfeca        ;lo nibble hex out on screen (hi part 1st)
                    LDA $fc,x        
                    JSR Sfeca        ;lo nibble hex out on screen
                    DEX              
                    BPL Lfeb0        
                    LDA #$20         ; (blank out 2 characters after address)
                    STA $d162        ;was $D0CA in syn600 (moved down on screen in this version)
                    STA $d163        ;was $D0CB
                    RTS              
Sfeca               AND #$0f         ;display low nibble of A as hex in next position on screen
                    ORA #$30         
                    CMP #$3a         
                    BMI Lfed5        
                    CLC              
                    ADC #$07         
Lfed5               STA $d15e,y      ;address of screen memory for display; SYN600 was $D0C6,Y
                    INY              
                    RTS              
Sfeda               LDY #$04         ;shift in low nibble as address on screen
                    ASL a            
                    ASL a            
                    ASL a            
                    ASL a            ;shift nibble down
Lfee0               ROL a            
                    ROL $fc,x        ;shift in bits of current address
                    ROL $fd,x        
                    DEY              
                    BNE Lfee0        ;*4 bits
                    RTS              
Sfee9               LDA $fb          ;(load flag for monitor when not 0)
                    BNE Lfe80        
Sfeed               JMP Lfd00        ;get key from keyboard

;$FEF0-FEF9 default $0218+ I/O vectors initialization
LFEF0               .WORD Sffba       ;input vector       
					.WORD Lff69       ;output vector      
					.WORD LFF9B       ;ctrl-c vector check
					.WORD LFF8B       ;load vector        
					.WORD Lff96       ;save vector
					.BYTE $30,$01     ;left over IRQ vector
					.BYTE $00,$fe     ;left over RESET vector
					.BYTE $c0,$01     ;left over NMI vector

;Reset vector entry 
LFF00               CLD
                    LDX #$28
                    TXS
                    LDY #$0a		;initialize I/O vectors
Lff06               LDA LFEF0-1,y
                    STA $0217,y
                    DEY
                    BNE Lff06
                    JSR Sfca6       ;reset ACIA @ $F000
                    STY $0212       ;CTRL-C flag !0 = ignore ctrl-c
                    STY $0203       ;LOAD flag
                    STY $0205       ;SAVE flag
                    STY $0206       ;time delay for CRT driver
                    LDA $ffe0       ;$FFE0 - cursor start
                    STA $0200
                    LDA #$20		;erase 1K screen
Lff26               ;STA $d300,y
                    ;STA $d200,y
					JSR Lfb1d
					BEQ Lff35					
                    NOP
					STA $d100,y
                    STA $d000,y
                    INY
                    BNE Lff26
					
Lff35               LDA LFF5F,y     ;display D/C/W/M ? prompt
                    BEQ Lff40
                    JSR $bf2d       ;BASIC screen print
                    INY
                    BNE Lff35
Lff40               JSR Sffba
                    CMP #'M
                    BNE Lff4a
                    JMP Lfe00	;ROM Monitor
                    
Lff4a               CMP #'W
                    BNE Lff51
                    JMP $0000	;jump to warm start
                    
Lff51               CMP #'C
                    BNE Lff58
                    JMP $bd11	;cold start
                    
Lff58               CMP #'D
                    BNE LFF00
                    JMP Lfc00	;disk boot
LFF5F
                    .BYTE 'D/C/W/M ?',0
                                 
Lff69               JSR $bf2d	;output vector
                    PHA
                    LDA $0205   ;load save flag
                    BEQ Lff94   ;branch if save not enabled
                    PLA
                    JSR Sfcb1   ;output to ACIA
                    CMP #$0d    ;was it <CR>?
                    BNE Lff95   ;branch if not
                    PHA
                    TXA
                    PHA         
                    LDX #$0a
                    LDA #$00
Lff81               JSR Sfcb1
                    DEX
Sff85               BNE Lff81
                    PLA
                    TAX
Lff89               PLA
                    RTS
LFF8B               PHA             ; (default load vector location here)
					DEC $0203       ;set load flag
					LDA #$00        ;load disable save flag
Lff91               STA $0205       ;store save flag
Lff94               PLA         
Lff95               RTS             ;exit
Lff96               PHA             ; (default save vector location here)
                    LDA #$01        ; set save flag above @ $0205
Sff99               BNE Lff91   
LFF9B               LDA $0212       ; (default ctrl-c check vector here) 0212=ignore ctrl-c when not 0	;ctrl-c vector check
                    BNE Lffb9
                    LDA #$fe        ;test for CTRL press
                    STA $df00
                    BIT $df00
                    BVS Lffb9
                    LDA #$fb        ;test for C press
                    STA $df00
                    BIT $df00
                    BVS Lffb9
                    LDA #$03
                    JMP $A636       ;send break req to BASIC
Lffb9				RTS
                    
Sffba               BIT $0203		;input vector
                    BPL Lffd8
Lffbf               LDA #$fd
                    STA $df00       ;test space bar press
                    LDA #$10
                    BIT $df00
                    BEQ Lffd5       ;branch if pressed
                    LDA $f000		;wait for serial character
                    LSR a
                    BCC Lffbf
                    LDA $f001		;unload ACIA
                    RTS             ;return value from ACIA
                    
Lffd5               INC $0203
Lffd8               JMP Lfd00       ; disable load flag
                    
                    .BYTE $FF,$FF,$FF,$FF,$FF
LFFE0               .BYTE $CD ; $FFE0 - cursor start
LFFE1				.BYTE $2f ; $FFE1 - line len-1   (wrap position)
LFFE2				.BYTE $01 ; $FFE2 - 00 = 1K vid, 01=2K vid otherwise serial or other ROM
                    .BYTE $00,$03
                    .BYTE $FF,$9F
                    .BYTE $00,$03
                    .BYTE $FF,$9F
					
Lffeb               JMP ($0218)     ;input vector             
Lffee               JMP ($021a)     ;output vector              
Lfff1               JMP ($021c)     ;ctrl-c vector check             
Lfff4               JMP ($021e)     ;load vector              
Lfff7               JMP ($0220)     ;save vector
                    
					.BYTE $30,$01    ;<IRQ>
                    .BYTE $00,$FF    ;<RESET>
                    .BYTE $C0,$01    ;<NMI>
.END