;There are 4 versions of CEGMON
; Standard Challenger C1P/Superboard aka C1 (24x24)
; Enhanced Challenger C1P/Superboard (48x32) aka C1E
; UK101 aka 101 (48x16)
; Challenger C2P (64x32) aka C2

; SEE **BUG FIX**
; This compiles under the portable A65 assembler version 1.25 or higher.

; NOTE: The original text indicated that the FCXX segment should be
; relocated to $F700 for C2/4.  To simplify the address circuitry, the
; ROM is wired to $F000-$FFFF, with A11 ignored, and the chip disabled
; when $FC00 (ACIA) is enabled.  This scheme maps the $FCXX segment to
; $F400 in hardware. If you follow the original CEGMON wiring instructions,
; change the relocation back to $F700.
; Note $F700 interferes with OSI500 CPU board PIA location @ $F700, so
; $F400 is recommended

;This code can be configured to build CEGMON compatible with OSI C2,
;OSI C1P and UK101 with 1K or 2K of video memory by changing the following
;flags. Set the version you want to '1' leaving the others '0'
C2VERSION=1 ;C2
C1P24X24=0  ;C1P/UK101 1K video memory 24x24 visible  C1
C1P48X16=0	;UK101/C1P 1K video memory 48x16 visible  UK101
C1P48X32=0  ;C1P/UK101 2K video memory 48x32 visible  C1E


;Cegmon screen handler commands
;CHR$(10) cursor down (LF)
;CHRS(11) cursor right
;CHR$(12) cursor home (top/left)
;CHR$(13) cursor to start of line (CR)
;CHR$(26) clear screen/home cursor, cursor visible
;CHR$(30) clear window/home cursor, cursor not displayed

;CEGMON addresses of interest
;$E0-$E6 storage for monitor interrupt/BRK support
;$0200	cursor displacement on current line
;$0201  stores current character during SCREEN; exits with character under cursor
;$0202  park for new character for SCREEN
;$0203  BASIC load flag 00=no load FF=load from ACIA
;$0204  EDITOR flag 00=disable edit FF=enable
;$0205  BASIC save flag 00=skip save 01=enable send to ACIA
;$0206  print delay value for SCREEN delay=value * ~400 microseconds @1MHz
;$0207 - $020E part of scroll routine (video dependent) LDA $D700,Y STA $D700,Y INY RTS
;$020F - $0211 not used
;$0212 BASIC CTRL-C flag 00=enable ctrl-c check 01=disable
;$0214 Auto-repeat counter for GETKEY
;$0215 return from GETKEY with final ASCII value
;$0216 pre-shift value of last key left by GETKEY to test autorepeat

;Window definitions
;location               C1       C1E      C2     UK101
;$0222 SWIDTH (cols-1)  $17      $2F      $3F     $2F
;$0223 SLTOP  top line  $85      $80      $80     $0C
;$0224 SHTOP            $D0      $D0      $D0     $D0
;$0225 SLBASE bottom ln $85      $40      $40     $CC
;$0226 SHBASE           $D3      $D7      $D7     $D3

;$022B  low byte of text-line start
;$022C  high byte of text-line start
;$022F  edit cursor displacement from start of editors current line
;$0230  storage for character under current editor cursor
;$0231  contains start of edit cursor's current line
;$0233  Monitor's User command 'U' address LOW
;$0234  Monitor's User command 'U' address HIGH




; SCREEN EDITOR Commands:
; Alter them as you desire
; Ctrl-E Toggle Editor on/off
EDITCHR=$05		;Ctrl-E
; Cursor Back
BACKCHR=$01		;Ctrl-A, Alternate ^B=#$02
; Cursor Forward
FORWCHR=$04		;Ctrl-D, Alternate ^F=#$06
; Prev. line (cursor up)
UPCHR=$13		;Ctrl-S
; Next line (cursor down)
DWNCHR=$06		;Ctrl-N, Alternate ^N=$0E
; Yank (copy character to input buffer)
COPYCHR=$19		;Ctrl-Y, Alternate ESC=$1B for C1&C2 / ^Q=$11 for UK101


;               NMI     IRQ     WIDTH   SIZE    START   COLS    ROWS
;C2/4           $130    $1C0    64      1       $80/128   64      28
;C1P/SBII       $130    $1C0    32      0       $45/69    24      26
;UK101          $130    $1C0    64      0       $8C/140   48      14

;Screen position & size definitions
.IF C2VERSION
;screen parameters for C2 64x28
WIDTH   =   $40             ; SCREEN WIDTH
SIZE    =   1               ; SCREEN SIZE 0=1K 1=2K
START   =   $80             ; SET SCREEN OFFSET OF TOP LEFT (3rd row)
COLS    =   64              ; SET COLUMNS TO DISPLAY
ROWS    =   28              ; SET ROWS TO DISPLAY
C2RELOC =   $F400			; REMAP $FCxx page to this value ($F400)
.ENDIF

.IF C1P24X24
;screen parameters for std. C1  24x26
WIDTH  =   $20             ; SCREEN WIDTH
SIZE   =   0               ; SCREEN SIZE 0=1K 1=2K
START  =   $45             ; SET SCREEN OFFSET OF TOP LEFT 3rd row 5 column
COLS   =   24              ; SET COLUMNS TO DISPLAY
ROWS   =   26              ; SET ROWS TO DISPLAY
.ENDIF

.IF C1P48X16
;screen parameters for UK101  48x14
WIDTH  =   $40             ; SCREEN WIDTH
SIZE   =   0               ; SCREEN SIZE 0=1K 1=2K
START  =   $8C ;$CD        ; SET SCREEN OFFSET OF TOP LEFT 3rd row 12 column
COLS   =   48              ; SET COLUMNS TO DISPLAY
ROWS   =   14  ;12         ; SET ROWS TO DISPLAY
.ENDIF

.IF C1P48X32
;screen parameters for enhanced C1 (2K vid)  48x28
WIDTH  =   $40             ; SCREEN WIDTH
SIZE   =   1               ; SCREEN SIZE 0=1K 1=2K
START  =   $8C             ; SET SCREEN OFFSET OF TOP LEFT 2nd row 12 column
COLS   =   48              ; SET COLUMNS TO DISPLAY
ROWS   =   28              ; SET ROWS TO DISPLAY
.ENDIF

;System definitions
BASIC   =   $A000   ; BASIC ROM
DISK    =   $C000   ; DISK CONTROLLER (PIA = +$00, ACIA = +$10)
SCREEN  =   $D000   ; SCREEN RAM
KEYBD   =   $DF00   ; KEYBOARD
NMI     =   $130    ; NMI ADDRESS
IRQ     =   $1C0    ; IRQ ADDRESS

; C1/C2 Serial Port
.IF C2VERSION
ACIA   =   $FC00   ; SERIAL PORT (MC6850 ACIA) FOR C2/C4
.ELSE
ACIA   =   $F000   ; SERIAL PORT (MC6850 ACIA) FOR C1/Superboard/UK101
.ENDIF

; BASIC ROM ROUTINES
; ROM BASIC provides ACIA I/O for the C2/4, which has the ACIA at
; $FC00.  The C1 must reproduce these in the monitor for the ACIA at
; $F000.  This ROM uses this reproduced code for both machines

LA34B   =   BASIC+$034B     ; UK101 BASIC RUBOUT KEY RETURN
LA374   =   BASIC+$0374     ; UK101 BASIC RUBOUT KEY RETURN
LA636   =   BASIC+$0636     ; CTRL-C HANDLER
LBD11   =   BASIC+$1D11     ; BASIC COLD START
;LBF15  =   BASIC+$1F15     ; OUTPUT CHAR TO ACIA (C2/C4)
;LBF22  =   BASIC+$1F22     ; INIT ACIA (C2/C4)

LBF2D   =   BASIC+$1F2D     ; ORIGINAL CRT SIMULATOR

;set variables based on selected screen parameters
SWIDTH  =  COLS-1
TOP     =  SCREEN+START
BASE    =  ROWS-1*WIDTH+TOP
BOT     =  SIZE+1*1024+SCREEN

;Start of ROM
*=      $F800

; RUBOUT
LF800   LDA $0E
        BEQ LF80A
        DEC $0E
        BEQ LF80A
        DEC $0E
LF80A   LDA #' '
        STA $0201
        JSR LFF8F
        BPL LF82D
        SEC
        LDA $022B
        SBC #WIDTH ;$40
        STA $022B
        LDA $022B+1
        SBC #$00
        STA $022B+1
        JSR LFBCF
        BCS LF82D
        JSR LFFD1
LF82D   STX $0200
        JSR LFF88
        JMP LF8D2

; NEW SCREEN

LF836   STA $0202
        PHA
        TXA
        PHA
        TYA
        PHA
        LDA $0202
        BNE LF846	; NOT NULL
        JMP LF8D2

LF846   LDY $0206	; SCREEN DELAY
        BEQ LF84E
        JSR LFCE1	;delay routine

LF84E   CMP #$5F
        BEQ LF800
        CMP #$0C
        BNE LF861

; CTRL-L

        JSR LFF8C
        JSR LFFD1
        STX $0200
        BEQ LF8CF

LF861   CMP #$0A
        BEQ LF88C
        CMP #$1E
        BEQ LF8E0
        CMP #$0B
        BEQ LF87D
        CMP #$1A
        BEQ LF8D8
        CMP #$0D
        BNE LF87A

; CR

        JSR LFF6D
        BNE LF8D2
LF87A   STA $0201

; CTRL-K

LF87D   JSR LFF8C
        INC $0200
        INX
        CPX $0222
        BMI LF8CF
        JSR LFF70

; LF

LF88C   JSR LFF8C
        LDY #$02
        JSR LFBD2
        BCS LF89E
        LDX #$03
        JSR LFDEE
        JMP LF8CF

LF89E   JSR LFE28
        JSR LFFD1
        JSR LFDEE
        LDX $0222
LF8AA   JSR $0227
        BPL LF8AA
        INX
        JSR LFDEE
        LDX #$03
        JSR LFDEE
        JSR LFBCF
        BCC LF8AA
        LDA #' '
LF8BF   JSR $022A
        BPL LF8BF
        LDX #$01
LF8C6   LDA $0223,X
        STA $0228,X
        DEX
        BPL LF8C6
LF8CF   JSR LFF75
LF8D2   PLA
        TAY
        PLA
        TAX
        PLA
        RTS

; CTRL-Z

LF8D8   JSR LFE59
        STA $0201
        BEQ LF904

; CTRL-SHIFT-N

LF8E0   LDA #' '
        JSR LFF8F
        JSR LFFD1
LF8E8   LDX $0222
        LDA #' '
LF8ED   JSR $022A
        BPL LF8ED
        STA $0201
        LDY #$02
        JSR LFBD2
        BCS LF904
        LDX #$03
        JSR LFDEE
        JMP LF8E8

LF904   JSR LFFD1
        STX $0200
        BEQ LF8D2

LF90C   JSR LF9A6
LF90F   JSR LFBF5
        JSR LFEB6
        JSR LFBE6
        JSR LFBE0
.IF C2VERSION
        LDX #$10    ; # BYTES DISPLAYED
.ELSE
		LDX #$08
.ENDIF
		STX $FD
LF91F   JSR LFBE6
        JSR LFEF0
        JSR LFBEB
        BCS LF97B
        JSR LFEF9
        DEC $FD
        BNE LF91F
        BEQ LF90F

; 'M'   MOVE MEMORY

LF933   JSR LFFBD
        JSR LFDE4
        BCS LF97E

; 'R'   RESTART FROM BREAKPOINT

LF93B   LDX $E4
        TXS
        LDA $E6
        PHA
        LDA $E5
        PHA
        LDA $E3
        PHA
        LDA $E0
        LDX $E1
        LDY $E2
        RTI

; 'Z'   SET BREAKPOINT

LF94E   LDX #$03
LF950   LDA LFA4C-1,X
        STA IRQ-1,X
        DEX
        BNE LF950
        JSR LFE8D
        JSR LF9B5
        LDA ($FE),Y
        STA $E7
        TYA
        STA ($FE),Y
        BEQ LF97E

; 'S'   SAVE

LF968   JMP LFA7E

; 'L'   LOAD

LF96B   DEC $FB
        BNE LF9E8

; 'T'   TABULAR DISPLAY

LF96F   BEQ LF90C
LF971   RTS

LF972   LDA $FB
        BNE LF971
        LDA #'?'
        JSR LFFEE	;OUTPUT

LF97B   LDX #$28
        TXS
LF97E   JSR LFBF5
        LDY #$00
        STY $FB
        JSR LFBE0

; '.'   COMMAND/ADDRESS MODE

LF988   JSR LFE8D
        CMP #'M'
        BEQ LF933
        CMP #'R'
        BEQ LF93B
        CMP #'Z'
        BEQ LF94E
        CMP #'S'
        BEQ LF968
        CMP #'L'
        BEQ LF96B
        CMP #'U'
        BNE LF9D6
        JMP ($0233)

LF9A6   JSR LFE8D
        JSR LF9B5
        JSR LFBE3
        LDX #$00
LF9B1   JSR LFE8D
        .BYTE $2C
LF9B5   LDX #$05
        JSR LF9C0
        JSR LFE8D
        .BYTE $2C
LF9BE   LDX #$03
LF9C0   JSR LF9C6
        JSR LFE8D
LF9C6   CMP #'.'
        BEQ LF988
        CMP #'/'
        BEQ LF9E8
        JSR LFE93
        BMI LF972
        JMP LFEDA

LF9D6   CMP #'T'
        BEQ LF96F
        JSR LF9B5

LF9DD   LDA #'/'
        JSR LFFEE	;OUTPUT
        JSR LFEF0
        JSR LFBE6

; '/'   DATA MODE

LF9E8   JSR LFE8D
        CMP #'G'
        BNE LF9F2
        JMP ($FE)

LF9F2   CMP #','
        BNE LF9FC
        JSR LFEF9
        JMP LF9E8

LF9FC   CMP #$A
        BEQ LFA16
        CMP #$D
        BEQ LFA1B
        CMP #'^'
        BEQ LFA21
        CMP #$27
        BEQ LFA3A
        JSR LF9BE
        LDA $FC
        STA ($FE),Y
LFA13   JMP LF9E8

LFA16   LDA #$D
        JSR LFFEE	;OUTPUT

LFA1B   JSR LFEF9
        JMP LFA31

; '^'

LFA21   SEC
        LDA $FE
        SBC #$01
        STA $FE
        LDA $FF
        SBC #$00
        STA $FF
LFA2E   JSR LFBF5

LFA31   JSR LFEB6
        JMP LF9DD

LFA37   JSR LFEF7

; "'"

LFA3A   JSR LFE8D
        CMP #$27
        BNE LFA46
        JSR LFBE3
        BNE LFA13
LFA46   CMP #$0D
        BEQ LFA2E
        BNE LFA37

LFA4C   JMP LFA4F

LFA4F   STA $E0
        PLA
        PHA
        AND #$10
        BNE LFA5A
        LDA $E0
        RTI

; SAVE REGISTERS ON BREAK

LFA5A   STX $E1
        STY $E2
        PLA
        STA $E3
        CLD
        SEC
        PLA
        SBC #$02
        STA $E5
        PLA
        SBC #$00
        STA $E6
        TSX
        STX $E4 ; **BUG FIX** (ORIGINAL VALUE WAS $E1)
        LDY #$00
        LDA $E7
        STA ($E5),Y
        LDA #$E0
        STA $FE
        STY $FF
        BNE LFA2E

LFA7E   JSR LFFBD
        JSR LFFF7
        JSR LFEE9
        JSR LFFEE	;OUTPUT
        JSR LFFE3
        LDA #'/'
        JSR LFFEE	;OUTPUT
        BNE LFA97
LFA94   JSR LFEF9

LFA97   JSR LFEF0
        LDA #$0D
        JSR LFCB1
        JSR LFBEB
        BCC LFA94
        LDA $E4
        LDX $E5
        STA $FE
        STX $FF
        JSR LFFE3
        LDA #'G'
        JSR LFFEE	;OUTPUT
        JSR LFFAC
        STY $205
        JMP LF97E

LFABD   TXA
        PHA
        TYA
        PHA
        LDA $204
        BPL LFB1F
LFAC6   LDY $22F
        LDA $231
        STA $E4
        LDA $231+1
        STA $E5
        LDA ($E4),Y
        STA $230
        LDA #$A1
        STA ($E4),Y
        JSR LFD00
        LDA $230
        STA ($E4),Y
        LDA $215
        CMP #COPYCHR		; (^Y) copy character to buffer
        BEQ LFB13
        CMP #BACKCHR		; (^A) Backward
        BEQ LFB0D
        CMP #FORWCHR		; (^F) Forward
        BEQ LFB07
        CMP #UPCHR  		; (^S) Prev line
        BEQ LFB01
        CMP #DWNCHR  		; (^D)/(^N) Next line)
        BNE LFB22

; CTRL-D (Next line)

        JSR LFB7C
        JMP LFAC6

; CTRL-S (Prev line)

LFB01   JSR LFE28
        JMP LFAC6

; CTRL-F (forward)

LFB07   JSR LFB6B
        JMP LFAC6

; CTRL-A (Backward)

LFB0D   JSR LFE19
        JMP LFAC6

; CTRL-Y (Yank/copy character)

LFB13   LDA $230
        STA $215
        JSR LFB6B
        JMP LFB43

LFB1F   JSR LFD00

LFB22   CMP #EDITCHR		;^E Editor on/off
        BNE LFB43
        LDA $204
        EOR #$FF
        STA $204
        BPL LFB1F
        LDA $22B
        STA $231
        LDA $22B+1
        STA $231+1
        LDX #$00
        STX $22F
        BEQ LFAC6
LFB43   JMP LFDD3

; INPUT

LFB46   BIT $203
        BPL LFB68   ; LOAD FLAG CLR
LFB4B
.IF C2VERSION
		LDA #$02
.ELSE
		LDA #$FD
.ENDIF
        STA KEYBD
        LDA #$10
        BIT KEYBD
.IF C2VERSION
        BNE LFB61   ; SPACE KEY PRESSED
.ELSE
		BEQ LFB61   ; SPACE KEY PRESSED
.ENDIF
; INPUT FROM ACIA

LFB57   LDA ACIA
        LSR
        BCC LFB4B
        LDA ACIA+1
        RTS

LFB61   LDA #$00
        STA $FB
        STA $203
LFB68   JMP LFABD

LFB6B   LDX $222
        CPX $22F
        BEQ LFB77
        INC $22F
        RTS

LFB77   LDX #$00
        STX $22F
LFB7C   CLC
        LDA $231
        ADC #WIDTH ;$40
        STA $231
        LDA $231+1
        ADC #$00
        CMP #>BOT ;$D8
        BNE LFB90
        LDA #>SCREEN
LFB90   STA $231+1
LFB93   RTS

; CTRL-C CHECK

LFB94   LDA $212
        BNE LFB93   ; DISABLE ^C FLAG SET
.IF C2VERSION
        LDA #$01
        STA KEYBD
        BIT KEYBD
        BVC LFB93
        LDA #$04
        STA KEYBD
        BIT KEYBD
        BVC LFB93
.ELSE ;C1versions
		LDA	#$FE
		STA	KEYBD
		BIT	KEYBD
		BVS	LFB93
		LDA	#$FB
		STA	KEYBD
		BIT	KEYBD
		BVS	LFB93
.ENDIF
        LDA #$03      ; CTRL-C PRESSED
        JMP LA636

		;DEFAULT I/O VECTOR TABLE
LFBB2   .WORD LFB46   ; 218 INPUT
        .WORD LFF9B   ; 21A OUTPUT
        .WORD LFB94   ; 21C CTRL-C
        .WORD LFE70   ; 21E LOAD
        .WORD LFE7B   ; 220 SAVE
        .BYTE SWIDTH  ; 222
        .WORD TOP     ; 223
        .WORD BASE    ; 225
        LDA TOP,X   ; 227
        STA TOP,X   ; 22A
        DEX         ; 22D
        RTS         ; 22E
        .BYTE $00     ; 22F
        .BYTE $20     ; 230
        .WORD TOP     ; 231
        .WORD LF988   ; 233

LFBCF   LDX $222
LFBD2   SEC
        LDA $22B
        SBC $223,Y
        LDA $22B+1
        SBC $223+1,Y
        RTS

LFBE0   LDA #'>'
        .BYTE $2C
LFBE3   LDA #','
        .BYTE $2C
LFBE6   LDA #' '
        JMP LFFEE	;OUTPUT

LFBEB   SEC
        LDA $FE
        SBC $F9
        LDA $FF
        SBC $FA
        RTS

; CRLF

LFBF5   LDA #$0D
        JSR LFFEE	;OUTPUT
        LDA #$0A
        JMP LFFEE	;OUTPUT

        .BYTE $40

; FLOPPY DISK BOOTSTRAP
.IF C2VERSION
*=C2RELOC	;Move this page to a different location in memory ($F400)
            ;This causes an A65 binary reposition error which can be safely ignored
.ENDIF
LFC00   JSR LFC0C
        JMP ($FD)

        JSR LFC0C
        JMP LFE00

LFC0C   LDY #$00		;init disk controller
        STY DISK+1      ;select DDRA.
        STY DISK        ;0's in DDRA indicate input.
        LDX #$04
        STX DISK+1      ;select PORTA
        STY DISK+3      ;select DDRB
        DEY
        STY DISK+2      ;1's in DDRB indicate output.
        STX DISK+3      ;select PORT B
        STY DISK+2      ;make all outputs high
        LDA #$FB
        BNE LFC33       ;step to track +1

LFC2A   LDA #$02
        BIT DISK		;test track 0 enabled?
        BEQ LFC4D
        LDA #$FF		;step down to 0
LFC33   STA DISK+2
        JSR LFCA5		;(short delay)
        AND #$F7		;step on
        STA DISK+2
        JSR LFCA5		;(short delay
        ORA #$08
        STA DISK+2		;step off
        LDX #$18
        JSR LFC91		;delay
        BEQ LFC2A
LFC4D   LDX #$7F		;load head
        STX DISK+2
        JSR LFC91		;delay
LFC55   LDA DISK
        BMI LFC55		;wait for index start
LFC5A   LDA DISK
        BPL LFC5A		;wait for index end
        LDA #$03
        STA DISK+$10	;reset disk ACIA
        LDA #$58
        STA DISK+$10	;/1 RTS hi, no irq
        JSR LFC9C
        STA $FE			;read start addr hi
        TAX
        JSR LFC9C
        STA $FD			;read start addr lo
        JSR LFC9C
        STA $FF			;read num pages
        LDY #$0
LFC7B   JSR LFC9C
        STA ($FD),Y		;read the specified num pages
        INY
        BNE LFC7B
        INC $FE
        DEC $FF
        BNE LFC7B
        STX $FE
        LDA #$FF		;disable drive
        STA DISK+2
        RTS

LFC91   LDY #$F8		;delay routine
LFC93   DEY
        BNE LFC93
        EOR $FF,X		;use some cycles
        DEX
        BNE LFC91
        RTS

; INPUT CHAR FROM DISK

LFC9C   LDA DISK+$10	;read a byte from disk
        LSR
        BCC LFC9C
        LDA DISK+$11
LFCA5   RTS

; INIT ACIA

LFCA6   LDA #$03      ; RESET ACIA
        STA ACIA
; (C1/C2) C2 initialize with $B1, C1 with $11  ($11 is a better choice)
.IF C2VERSION
        LDA #$B1    ; /16, 8BITS, 2STOP, RTS LOW, RX INT
.ELSE
        LDA #$11    ; /16, 8BITS, 2STOP, RTS LOW
.ENDIF
        STA ACIA
        RTS

; OUTPUT CHAR TO ACIA

LFCB1   PHA
LFCB2   LDA ACIA
        LSR
        LSR
        BCC LFCB2
        PLA
        STA ACIA+1
        RTS

; C1 SET KEYBOARD ROW (A)  1=R0, 2=R1, 4=R2 ETC

LFCBE   EOR #$FF
        STA KEYBD
        EOR #$FF
        RTS

; C1 READ KEYBOARD COL (X) 1=C0, 2=C1, 4=C2, 0=NONE

LFCC6   PHA
        JSR LFCCF
        TAX
        PLA
        DEX
        INX
        RTS

LFCCF   LDA KEYBD
        EOR #$FF
        RTS

; UK101 UKBASIC ROM RUBOUT KEY HANDLER

LFCD5   CMP #$5F    ; RUBOUT
        BEQ LFCDC
        JMP LA374

LFCDC   JMP LA34B

; DELAY

LFCDF   LDY #$10
LFCE1   LDX #$40
LFCE3   DEX
        BNE LFCE3
        DEY
        BNE LFCE1
        RTS

LFCEA  .BYTE   'CEGMON(C)1980 D/C/W/M?'

; POLLED KEYBOARD INPUT ROUTINE
*=$FD00		;now return A65 to previous ROM location if C2 version
LFD00   TXA
        PHA
        TYA
        PHA

LFD04   LDA #$80    ; ROW 7
LFD06
.IF C2VERSION
		STA KEYBD   ; SET ROW
        LDX KEYBD   ; READ COL
.ELSE
		JSR	LFCBE	; SET ROW C1P
		JSR LFCC6	; READ COL C1P
.ENDIF
        BNE LFD13   ; ANY KEYS PRESSED?
        LSR A 		; NEXT ROW
        BNE LFD06
        BEQ LFD3A	;

LFD13   LSR A
        BCC LFD1F
        TXA
        AND #$20
        BEQ LFD3A
        LDA #$1B
        BNE LFD50

LFD1F   JSR LFE86
        TYA
        STA $0215	;store row index
        ASL A		;multiply by 8
        ASL A
        ASL A
        SEC
        SBC $0215	;subtract 1 = (*7)
        STA $0215
        TXA
        LSR A
        ASL A
        JSR LFE86
        BEQ LFD47
        LDA #$00
LFD3A   STA $0216
LFD3D   STA $0213
        LDA #$02
        STA $0214
        BNE LFD04

LFD47   CLC
        TYA
        ADC $0215
        TAY
        LDA LFF3C-1,Y

LFD50   CMP $0213
        BNE LFD3D
        DEC $0214
        BEQ LFD5F
        JSR LFCDF
        BEQ LFD04

LFD5F   LDX #$64
        CMP $0216
        BNE LFD68
        LDX #$0F
LFD68   STX $0214
        STA $0216
        CMP #$21
        BMI LFDD0

        CMP #$5F
        BEQ LFDD0

        LDA #$01
.IF C2VERSION
        STA KEYBD
        LDA KEYBD
.ELSE
		JSR	LFCBE
		JSR	LFCCF
.ENDIF
        STA $0215
        AND #$01
        TAX
        LDA $0215
        AND #$06
        BNE LFDA2
        BIT $0213
        BVC LFDBB
        TXA
        EOR #$01
        AND #$01
        BEQ LFDBB
        LDA #$20
        BIT $0215
        BVC LFDC3
        LDA #$C0
        BNE LFDC3

LFDA2   BIT $0213
        BVC LFDAA
        TXA
        BEQ LFDBB
LFDAA   LDY $0213
        CPY #$31
        BCC LFDB9
        CPY #$3C
        BCS LFDB9
        LDA #$F0
        BNE LFDBB

LFDB9   LDA #$10
LFDBB   BIT $0215
        BVC LFDC3
        CLC
        ADC #$C0
LFDC3   CLC
        ADC $0213
        AND #$7F
        BIT $0215
        BPL LFDD0
        ORA #$80
LFDD0   STA $0215
LFDD3   PLA
        TAY
        PLA
        TAX
        LDA $0215
        RTS

LFDDB   JSR LFEF9
        INC $E4
        BNE LFDE4
        INC $E5
LFDE4   LDA ($FE),Y
        STA ($E4),Y
        JSR LFBEB
        BCC LFDDB
        RTS

LFDEE   CLC
        LDA #WIDTH ;$40
        ADC $0228,X
        STA $0228,X
        LDA #$00
        ADC $0228+1,X
        STA $0228+1,X
        RTS

; 65V MONITOR

LFE00   LDX #$28
        TXS
        CLD
        JSR LFCA6
        JSR LFE40
        NOP
        NOP
        JSR LFE59
        STA $201
        STY $FE
        STY $FF
        JMP LF97E

LFE19   LDX $22F
        BEQ LFE22
        DEC $22F
        RTS

LFE22   LDX $222
        STX $22F
LFE28   SEC
        LDA $231
        SBC #WIDTH ;$40
        STA $231
        LDA $231+1
        SBC #$00
        CMP #>SCREEN-1 ;$CF
        BNE LFE3C
        LDA #>BOT-1 ;$D7
LFE3C   STA $231+1
        RTS

LFE40   LDY #$1C    ; INIT 218-234
LFE42   LDA LFBB2,Y
        STA $218,Y
        DEY
        BPL LFE42
        LDY #$07	; ZERO 200-206, 212
        LDA #$00
        STA $212	; ENABLE CTRL-C FLAG
LFE52   STA $200-1,Y
        DEY
        BNE LFE52
        RTS

; CLEAR SCREEN

LFE59   LDY #$00
        STY $F9
        LDA #>SCREEN
        STA $FA
        LDX #SIZE+1*4 ;8
        LDA #' '
LFE65   STA ($F9),Y
        INY
        BNE LFE65
        INC $FA
        DEX
        BNE LFE65
        RTS

; LOAD

LFE70   PHA
        DEC $0203    ; SET LOAD FLAG
        LDA #$00     ; CLR SAVE FLAG
LFE76   STA $0205
        PLA
        RTS

; SAVE

LFE7B   PHA
        LDA #$01      ; SET SAVE FLAG
        BNE LFE76

; INPUT CHAR FROM ACIA

LFE80   JSR LFB57
        AND #$7F    ; CLEAR BIT 7
        RTS

LFE86   LDY #$08
LFE88   DEY
        ASL A
        BCC LFE88
        RTS

LFE8D   JSR LFEE9
        JMP LFFEE	;OUTPUT

; CONVERT ASCII-HEX CHAR TO BINARY

LFE93   CMP #'0'
        BMI LFEA9
        CMP #'9'+1
        BMI LFEA6
        CMP #'A'
        BMI LFEA9
        CMP #'F'+1
        BPL LFEA9
        SEC
        SBC #$07
LFEA6   AND #$0F
        RTS

LFEA9   LDA #$80
        RTS

        JSR LFEB6
        NOP
        NOP
        JSR LFBE6
        BNE LFEBD
LFEB6   LDX #$03
        JSR LFEBF
        DEX
        .BYTE $2C
LFEBD   LDX #$00

LFEBF   LDA $FC,X
        LSR
        LSR
        LSR
        LSR
        JSR LFECA
        LDA $FC,X
LFECA   AND #$0F
        ORA #'0'
        CMP #'9'+1
        BMI LFED5
        CLC
        ADC #$07
LFED5   JMP LFFEE	;OUTPUT

        .BYTE $EA,$EA

LFEDA   LDY #$04
        ASL A
        ASL A
        ASL A
        ASL A
LFEE0   ROL A
        ROL $F9,X
        ROL $FA,X
        DEY
        BNE LFEE0
        RTS

LFEE9   LDA $FB
        BNE LFE80
        JMP LFD00

LFEF0   LDA ($FE),Y
        STA $FC
        JMP LFEBD

LFEF7   STA ($FE),Y
LFEF9   INC $FE
        BNE LFEFF
        INC $FF
LFEFF   RTS

; POWER ON RESET

LFF00   CLD
        LDX #$28
        TXS
        JSR LFCA6
        JSR LFE40
        JSR LFE59
.IF C2VERSION
        STY $200
.ELSE
		JSR	LFFD1
.ENDIF

LFF10   LDA LFCEA,Y
        JSR LFFEE	;OUTPUT
        INY
        CPY #$16
        BNE LFF10

        JSR LFFEB
        AND #$DF
        CMP #'D'
        BNE LFF27
        JMP LFC00  ;Disk Boot

LFF27   CMP #'M'	;Monitor
        BNE LFF2E
        JMP LFE00

LFF2E   CMP #'W'
        BNE LFF35
        JMP 0		;Warm Start

LFF35   CMP #'C'
        BNE LFF00
        JMP LBD11

; KEYBOARD MATRIX

LFF3C   .BYTE   'P',';','/',$20,'Z','A','Q'
        .BYTE   ',','M','N','B','V','C','X'
        .BYTE   'K','J','H','G','F','D','S'
        .BYTE   'I','U','Y','T','R','E','W'
        .BYTE   $00,$00,$0D,$0A,'O','L','.'
        .BYTE   $00,$5F,'-',':','0','9','8'
        .BYTE   '7','6','5','4','3','2','1'

LFF6D   JSR LFF8C

LFF70   LDX #0
        STX $200
LFF75   LDX $200
        LDA #$BD    ; LDA ABS,X
        STA $22A
        JSR $22A
        STA $201
        LDA #$9D    ; STA ABS,X
        STA $22A
LFF88   LDA #$5F
        BNE LFF8F

LFF8C   LDA $201
LFF8F   LDX $200
        JMP $22A

; OLD SCREEN

LFF95   JSR LBF2D
        JMP LFF9E

; OUTPUT

LFF9B   JSR LF836
LFF9E   PHA
        LDA $205
        BEQ LFFBB   ; SAVE FLAG CLR
        PLA
        JSR LFCB1    ; CHAR TO ACIA
        CMP #$D
        BNE LFFBC   ; NOT CR

; 10 NULLS

LFFAC   PHA
        TXA
        PHA
        LDX #$A
        LDA #0
LFFB3   JSR LFCB1
        DEX
        BNE LFFB3
        PLA
        TAX
LFFBB   PLA
LFFBC   RTS

LFFBD   JSR LF9A6
        JSR LFBE0
        LDX #$03
        JSR LF9B1
        LDA $FC
        LDX $FD
        STA $E4
        STX $E5
        RTS

; SET DEFAULT WINDOW

LFFD1   LDX     #$02
LFFD3   LDA     $0223-1,X
        STA     $0228-1,X
        STA     $022B-1,X
        DEX
        BNE     LFFD3
        RTS

LFFE0
.IF C2VERSION
		.BYTE <BASE 	; CURSOR START
.ELSE
		.BYTE <BASE+1 	; CURSOR START
.ENDIF
LFFE1   .BYTE SWIDTH	; LINE LENGTH - 1
LFFE2   .BYTE SIZE  	; SCREEN SIZE 0=1K 1=2K

LFFE3   LDA #'.'
        JSR LFFEE	;OUTPUT
        JMP LFEB6

LFFEB   JMP ($218)		; INPUT VECTOR  FB46
LFFEE   JMP ($21A)		; OUTPUT VECTOR FF9B
LFFF1   JMP ($21C)		; CTRL-C CHECK VECTOR FB94
LFFF4   JMP ($21E)		; LOAD VECTOR   FE70
LFFF7   JMP ($220)		; SAVE VECTOR   FE7B

        .WORD NMI  		; NMI LOCATION
        .WORD LFF00		; RESET
        .WORD IRQ  		; IRQ LOCATION

        .END
