
The Cegmonx.asm file can be assembled to create CEGMON monitors for C1, C1E, C2/C4, and UK101
using the A65 portable 6502 assembler V1.25 or higher. Find A65 @ https://osi.marks-lab.com/tools.html
Modify the cegmonx.asm assembler file to fit your target needs then use the command:
A65 -p0 -l -b cegmonx.asm  
to create the cegmonx.bin file and a assembler listing for your target configuration.